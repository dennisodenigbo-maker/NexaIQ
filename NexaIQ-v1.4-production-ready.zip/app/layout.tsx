import './globals.css';
export const metadata={title:'NexaIQ — Your AI Business Analyst',description:'AI-powered business intelligence for growing businesses.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
