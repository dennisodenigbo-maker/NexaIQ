import { NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase-server';

export async function POST(req: Request) {
  try {
    const sb = await createServerSupabase();
    if (sb) {
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
    }
    const { question, data } = await req.json();
    if (!question) return NextResponse.json({ error: 'Question is required.' }, { status: 400 });
    if (!process.env.OPENAI_API_KEY) return NextResponse.json({ answer: 'AI is not connected yet. Add an AI provider key in deployment settings to enable natural-language analysis.' });
    const model = process.env.OPENAI_MODEL;
    if (!model) return NextResponse.json({ error: 'OPENAI_MODEL is not configured.' }, { status: 500 });
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: JSON.stringify({ model, input: [
        { role: 'system', content: 'You are NexaIQ, a concise B2B business analyst. Analyze only the supplied business data. State assumptions and avoid inventing numbers.' },
        { role: 'user', content: `Business data:
${JSON.stringify(data).slice(0, 50000)}

Question: ${question}` }
      ] })
    });
    if (!response.ok) return NextResponse.json({ error: 'AI provider request failed.' }, { status: 502 });
    const json = await response.json();
    const answer = json.output_text || json.output?.map((x: any) => x.content?.map((c: any) => c.text || '').join('')).join('') || 'No analysis returned.';
    return NextResponse.json({ answer });
  } catch { return NextResponse.json({ error: 'Analysis failed.' }, { status: 500 }); }
}
