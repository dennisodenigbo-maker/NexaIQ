import { NextResponse } from 'next/server';
import Papa from 'papaparse';
import { summarize } from '@/lib/analytics';
import { createServerSupabase } from '@/lib/supabase-server';

export async function POST(req: Request) {
  try {
    const sb = await createServerSupabase();
    if (sb) {
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });
    }
    const body = await req.json();
    const csv = String(body.csv || '');
    if (!csv) return NextResponse.json({ error: 'CSV data is required.' }, { status: 400 });
    if (csv.length > 5 * 1024 * 1024) return NextResponse.json({ error: 'CSV exceeds the 5 MB MVP limit.' }, { status: 413 });
    const parsed = Papa.parse<Record<string, unknown>>(csv, { header: true, skipEmptyLines: true });
    if (parsed.errors.length) return NextResponse.json({ error: parsed.errors[0].message }, { status: 400 });
    const rows = parsed.data;
    if (!rows.length) return NextResponse.json({ error: 'CSV contains no data rows.' }, { status: 400 });
    return NextResponse.json({ rows, schema: Object.keys(rows[0] || {}), summary: summarize(rows) });
  } catch { return NextResponse.json({ error: 'Unable to process the file.' }, { status: 400 }); }
}
