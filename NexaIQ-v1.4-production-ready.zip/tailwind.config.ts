import type {Config} from 'tailwindcss';
const config:Config={content:['./app/**/*.{ts,tsx}','./components/**/*.{ts,tsx}'],theme:{extend:{colors:{ink:'#101828',brand:'#155EEF',soft:'#F5F8FF'}}},plugins:[]}; export default config;
