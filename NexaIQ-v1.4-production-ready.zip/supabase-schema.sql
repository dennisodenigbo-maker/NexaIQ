create extension if not exists pgcrypto;
create table if not exists public.workspaces (id uuid primary key default gen_random_uuid(), name text not null, owner_id uuid not null references auth.users(id) on delete cascade, created_at timestamptz not null default now());
create table if not exists public.workspace_members (workspace_id uuid not null references public.workspaces(id) on delete cascade, user_id uuid not null references auth.users(id) on delete cascade, role text not null default 'member' check(role in ('owner','member')), created_at timestamptz not null default now(), primary key(workspace_id,user_id));
create table if not exists public.datasets (id uuid primary key default gen_random_uuid(), workspace_id uuid not null references public.workspaces(id) on delete cascade, name text not null, row_count integer not null default 0, summary jsonb not null default '{}'::jsonb, created_at timestamptz not null default now());
create table if not exists public.ai_queries (id uuid primary key default gen_random_uuid(), workspace_id uuid not null references public.workspaces(id) on delete cascade, question text not null, answer text, created_at timestamptz not null default now());
alter table public.workspaces enable row level security; alter table public.workspace_members enable row level security; alter table public.datasets enable row level security; alter table public.ai_queries enable row level security;
create policy "workspace members can read workspaces" on public.workspaces for select using (owner_id=auth.uid() or exists(select 1 from public.workspace_members m where m.workspace_id=id and m.user_id=auth.uid()));
create policy "owners can create workspaces" on public.workspaces for insert with check(owner_id=auth.uid());
create policy "members can read datasets" on public.datasets for select using (exists(select 1 from public.workspace_members m where m.workspace_id=workspace_id and m.user_id=auth.uid()) or exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));
create policy "members can read ai queries" on public.ai_queries for select using (exists(select 1 from public.workspace_members m where m.workspace_id=workspace_id and m.user_id=auth.uid()) or exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));

-- Write policies needed by the MVP application
create policy "owners can add workspace members" on public.workspace_members
  for insert with check (user_id=auth.uid() and exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));
create policy "members can read membership" on public.workspace_members
  for select using (user_id=auth.uid() or exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));
create policy "members can create datasets" on public.datasets
  for insert with check (exists(select 1 from public.workspace_members m where m.workspace_id=workspace_id and m.user_id=auth.uid()) or exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));
create policy "members can create ai queries" on public.ai_queries
  for insert with check (exists(select 1 from public.workspace_members m where m.workspace_id=workspace_id and m.user_id=auth.uid()) or exists(select 1 from public.workspaces w where w.id=workspace_id and w.owner_id=auth.uid()));
