import {Row} from './analytics';
const num=(v:unknown)=>{const n=Number(String(v??'').replace(/[$,\s]/g,''));return Number.isFinite(n)?n:0};
export function forecastRevenue(rows:Row[], periods=3){const values=rows.map(r=>num(r.revenue??r.sales??r.amount)).filter(v=>v>0);if(values.length<2)return [];const n=values.length,meanX=(n-1)/2,meanY=values.reduce((a,b)=>a+b,0)/n;const denom=values.reduce((a,_,i)=>a+(i-meanX)**2,0)||1;const slope=values.reduce((a,y,i)=>a+(i-meanX)*(y-meanY),0)/denom;const last=values[n-1];return Array.from({length:periods},(_,i)=>Math.max(0,last+slope*(i+1)))}
