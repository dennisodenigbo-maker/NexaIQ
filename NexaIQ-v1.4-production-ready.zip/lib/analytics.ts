export type Row=Record<string, unknown>;
const num=(v:unknown)=>{const n=Number(String(v??'').replace(/[$,\s]/g,''));return Number.isFinite(n)?n:0};
export function summarize(rows:Row[]){
  const revenue=rows.reduce((s,r)=>s+num(r.revenue??r.sales??r.amount),0);
  const expenses=rows.reduce((s,r)=>s+num(r.expenses??r.cost??r.costs),0);
  const orders=rows.reduce((s,r)=>s+num(r.orders??r.quantity??1),0);
  const profit=revenue-expenses;
  return {rows:rows.length,revenue,expenses,profit,orders,margin:revenue?profit/revenue:0};
}
export function demoRows(){return [
 {month:'Jan',revenue:82000,expenses:47000,orders:1220},{month:'Feb',revenue:91000,expenses:50000,orders:1305},{month:'Mar',revenue:98000,expenses:52000,orders:1410},{month:'Apr',revenue:108000,expenses:56000,orders:1520},{month:'May',revenue:119000,expenses:59000,orders:1680},{month:'Jun',revenue:128450,expenses:61630,orders:1707}
]}
