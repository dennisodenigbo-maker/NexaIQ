# NexaIQ — B2B AI Business Intelligence MVP v1.4

NexaIQ is a B2B SaaS MVP for businesses to upload sales/expense data, calculate KPIs, forecast revenue, and ask an AI analyst questions about their business data.

## v1.4 production hardening
- Supabase browser authentication
- Server-side auth checks on ingestion and AI analysis routes
- Supabase SSR middleware for session refresh
- Workspace/member/dataset/AI-query database schema with RLS
- CSV validation and 5 MB API-side limit
- AI provider key kept server-side
- Vercel-ready Next.js project

## Launch checklist
1. Create a Supabase project.
2. Run `supabase-schema.sql` in Supabase SQL Editor.
3. Enable Email authentication in Supabase Auth.
4. Set the Site URL to your final production domain and add the authentication redirect URL.
5. Create an AI API key and choose a supported model.
6. Push this project to GitHub.
7. Import the GitHub repository into Vercel.
8. Add `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `OPENAI_API_KEY`, and `OPENAI_MODEL` to Vercel Environment Variables.
9. Deploy and test signup, login, CSV upload, dashboard calculations and AI analysis.
10. Only after successful testing, connect your purchased domain in Vercel.

## Local setup
Node.js 18+ recommended.

```bash
npm install
cp .env.example .env.local
npm run dev
```

## Important
This is an MVP, not yet a compliance-certified production system. Before accepting sensitive customer data, add billing, rate limiting, monitoring, backups, audit logs, data retention/deletion controls, and a reviewed privacy policy/terms.
